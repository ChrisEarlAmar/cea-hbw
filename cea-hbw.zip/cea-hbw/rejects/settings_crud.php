<?php

    require('../inc/db_config.php');
    require('../inc/essentials.php');
    adminLogin();

    if (isset($_POST['get_general'])) {
        $q = "SELECT * FROM `settings` WHERE `sr_no` = ?";
        $values = [1];
        $types = "i";
        $res = select($q, $values, $types);

        if ($res) {
            $data = mysqli_fetch_assoc($res);
            header('Content-Type: application/json');
            echo json_encode($data);
        } else {
            header('Content-Type: application/json');
            echo json_encode(array('error' => 'Database error'));
        }
    } else {
        header('Content-Type: application/json');
        echo json_encode(array('error' => 'Invalid request'));
    }

    if (isset($_POST['upd_general'])) {
        $frm_data = filteration($_POST);
    
        $q = "UPDATE `settings` SET `site_title`=?, `site_about`=?, `shutdown`=? WHERE `sr_no`=?";
    
        $values = [$frm_data['site_title'], $frm_data['site_about'], 1, 1];
        $types = "ssii"; 
    
        $res = update($q, $values, $types);
    
        echo $res;
    }
    
    
?>
