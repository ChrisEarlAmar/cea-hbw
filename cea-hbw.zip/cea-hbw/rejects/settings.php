<?php
    require('inc/essentials.php');
    require('inc/db_config.php');
    adminLogin();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Settings</title>
    <!-- Links for CSS and JS -->
    <?php require('inc/links.inc.php') ?>
</head>
<body class="bg-light">

    <!-- Header -->
    <?php require('inc/header.inc.php');?>

    <div class="container-fluid" id="main_content">
        <div class="row">
            <div class="col-lg-10 ms-auto p-4 overflow-hidden">

                <h3 class="mb-4">SETTINGS</h3>

                <!-- General Settings -->
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex align-items-center justify-content-between mb-3">
                            <h5 class="card-title m-0">General Settings</h5>
                            <button type="button" class="btn btn-dark shadow-none btn-sm" data-bs-toggle="modal" data-bs-target="#general_s">
                                <i class="bi bi-pencil-square text-white me-1"></i> Edit
                            </button>
                        </div>
                        <h6 class="card-subtitle mb-1 fw-bold">Site Title</h6>
                        <p class="card-text" id="site_title"></p>
                        <h6 class="card-subtitle mb-1 fw-bold">About us</h6>
                        <p class="card-text" id="site_about"></p>
                    </div>
                </div>

                <!-- General Settings Modal -->
                <div class="modal fade" id="general_s" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="general_s" aria-hidden="true">
                    <div class="modal-dialog">
                        <form>
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">General Settings</h5>
                                    <button type="button" class="btn-close shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <div class="mb-3">
                                        <label for="site_title_modal_input" class="form-label">Site Title</label>
                                        <input type="text" class="form-control shadow-none" name="site_title" id="site_title_modal_input">
                                    </div>
                                    <div class="mb-3">
                                        <label for="site_about_modal_input" class="form-label">About us</label>
                                        <textarea class="form-control shadow-none" name="site_about" id="site_about_modal_input" rows="6"></textarea>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" onclick="resetFormValues()" class="btn text-secondary shadow-none" data-bs-dismiss="modal">CANCEL</button>
                                    <button type="button" onclick="submitForm()" class="btn custom-bg text-white shadow-none">SAVE</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>

</body>
    <!-- Script -->
    <?php require('inc/script.inc.php') ?>

    <script>

    let general_data;

    function get_general() {
        let site_title = document.getElementById('site_title');
        let site_about = document.getElementById('site_about');

        let site_title_modal_input = document.getElementById('site_title_modal_input');
        let site_about_modal_input = document.getElementById('site_about_modal_input');

        let xhr = new XMLHttpRequest();
        xhr.open("POST", "ajax/settings_crud.php", true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

        xhr.onload = function() {
            if (xhr.status === 200) {
                try {
                    let response = JSON.parse(xhr.responseText);

                    if (response.hasOwnProperty('error')) {
                        console.error("Server returned an error:", response.error);
                    } else {
                        general_data = response;

                        if (site_title && site_about) {
                            site_title.innerText = general_data.site_title;
                            site_about.innerText = general_data.site_about;

                            site_title_modal_input.value = general_data.site_title;
                            site_about_modal_input.value = general_data.site_about;
                        } else {
                            console.error("DOM elements not found.");
                        }
                    }
                } catch (error) {
                    console.error("Error parsing JSON:", error);
                }
            } else {
                console.error("Request failed with status:", xhr.status);
            }
        };

        xhr.send('get_general=true');
    }

    function resetFormValues() {
        let site_title_modal_input = document.getElementById('site_title_modal_input');
        let site_about_modal_input = document.getElementById('site_about_modal_input');

        site_title_modal_input.value = general_data.site_title;
        site_about_modal_input.value = general_data.site_about;
    }

    function submitForm() {
        let site_title_modal_input = document.getElementById('site_title_modal_input');
        let site_about_modal_input = document.getElementById('site_about_modal_input');

        upd_general(site_title_modal_input.value, site_about_modal_input.value);
    }

    function upd_general(site_title_val, site_about_val) {

        let xhr = new XMLHttpRequest();
        xhr.open("POST", "ajax/settings_crud.php", true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

        xhr.onload = function() {
            console.log(this.responseText);
        }

        let data = new URLSearchParams();
        data.append('upd_general', true);
        data.append('site_title', site_title_val);
        data.append('site_about', site_about_val);

        xhr.send(data);

}

    window.onload = function() {
        get_general();
    };

    </script>

</html>
